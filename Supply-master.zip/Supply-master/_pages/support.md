---
title: Support / Terms
permalink: /support/
hero: Support
---

### Shipping

Add your company shipping terms here.

### Returns

Add your company return policy here.


### Support and contact

For any question about a template, feel free to [reach out](/contact/).
Please write about your issue, inquiry or suggestion in detail to help us help you.
