---
title: Privacy
permalink: /privacy/
hero: Privacy
---

This website does not collect or store any data and does not use cookies or tracking/analytics services.

This site uses the Gumroad e-commerce platform. Please refer to [Gumroad's privacy policy](https://gumroad.com/privacy) for further information.
