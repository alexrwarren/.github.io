---
title: This is an updated post
layout: post
date: 2020-04-19 13:20:50 +0100
last_modified_at: '2020-05-17'
description_markdown: >-
  Start a blog or a static site with Jekyll.
date: 2020-04-16 12:48:59 +0100
image: /images/templates/assignments/assignments_tracker_spreadsheet.png
categories: [Jekyll, tutorial]
tags: [updated]
---
This is a recently updated blog post example. Add `last_modified_at: YYYY-MM-DD` in any posts YAML front-matter. Your sitemap will be automatically updated.
